from celery import shared_task
from django.core.mail import send_mail
from django.template.loader import render_to_string

@shared_task
def hello_world():
    subject = 'Hello from Celery'
    message = 'This is a plain-text fallback.'
    from_email = 'imvickykumar999@gmail.com'
    recipient_list = ['vicky@bol7.com', '18erecs080.vicky@rietjaipur.ac.in']

    # 👇 Pass context dictionary here
    context = {
        'name': 'Vicky',
        'custom_message': 'Your scheduled task ran successfully!',
    }

    html_message = render_to_string('email/hello_email.html', context)

    send_mail(
        subject,
        message,
        from_email,
        recipient_list,
        fail_silently=False,
        html_message=html_message
    )

    print("Email sent with dynamic HTML content.")
    return "HTML email with variables sent"
