from django.http import HttpResponse
from core.tasks import hello_world

def trigger_email(request):
    hello_world.delay()
    return HttpResponse("Email task triggered")
